## intent:agent.bridge.cautranthily
- cầu trần thị lý
- trần thị lý
- cầu trần thị lý đà nẵng
- cầu trần thị lý ở đà nẵng
- ý nghĩa cầu trần thị lý
- cầu trần thị lý ban đêm
- giới thiệu về cầu trần thị lý đà nẵng
- thiết kế cầu trần thị lý
- ảnh cầu trần thị lý