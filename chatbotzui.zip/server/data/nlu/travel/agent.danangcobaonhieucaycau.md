## intent:agent.danangcobaonhieucaycau
- cầu ở đã nẵng
- đà nẵng có bao nhiêu cây cầu
- đà nẵng có mấy cây cầu
- có bao nhiều cây càu
- có bao nhiêu cầu bắc qua sông hàn
- sông hàn có bao nhiêu cây cầu
- cầu nổi tiếng ở đà nẵng