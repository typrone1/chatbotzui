## story 29
*agent.right
    - utter_agent.right
    
## story 30
*agent.sure
    - utter_agent.sure

## story 33
*appraisal.bad
    - utter_appraisal.bad
    
## story 34
*appraisal.good
    - utter_appraisal.good
## story 36
*appraisal.thank_you
    - utter_appraisal.thank_you

## story 42
*dialog.sorry
    - utter_dialog.sorry

## story 44
*dialog.wrong
    - utter_dialog.wrong

## story 45
*emotions.ha_ha
    - utter_emotions.ha_ha
    

## story 47
*greetings.bye
    - utter_greetings.bye

## story 84
*confirmation.yes
    - utter_confirmation.yes

## story 85
*confirmation.cancel
    - utter_confirmation.cancel

## story 86
*confirmation.no
    - utter_confirmation.no

## story 100
*agent.whatisdanang
    - utter_agent.whatisdanang

## story 101
*agent.danangcobaonhieucaycau
    - utter_agent.danangcobaonhieucaycau

## story 102
*agent.bridge.cautranthily
    - utter_agent.bridge.cautranthily

## story 103
*agent.bridge.caurong
    - utter_agent.bridge.caurong

## story 104
*agent.bridge.causonghan
    - utter_agent.bridge.causonghan

## story 105
*agent.bridge.cauthuanphuoc
    - utter_agent.bridge.cauthuanphuoc

## story 106
*agent.bridge.caunguyenvantroi
    - utter_agent.bridge.caunguyenvantroi

## story 107
* agent.request_suggest_near_location
    - utter_ask_location

## story 108
* agent.request_suggest_near_location
    - utter_ask_location
* inform{"location": "Hải Châu"}
    - utter_ask_price
* inform{"price": "miễn phí"}
    - utter_ask_moreupdates
* confirmation.yes
    - utter_ask_moreupdates
* confirmation.no
    - utter_suggest_location_haichau
* appraisal.thank_you
    - utter_appraisal.thank_you

## story 109
* agent.request_suggest_near_location
    - utter_ask_location
* inform{"location": "Hải Châu"}
    - utter_ask_price
* inform{"price": "miễn phí"}
    - utter_ask_moreupdates
* confirmation.no
    - utter_suggest_location_haichau
* appraisal.thank_you
    - utter_appraisal.thank_you

## story 108
* agent.request_suggest_near_location
    - utter_ask_location
* inform{"location": "Hải Châu"}
    - utter_ask_price
* inform{"price": "miễn phí"}
    - utter_ask_moreupdates
* confirmation.yes
    - utter_ask_moreupdates
* confirmation.no
    - utter_suggest_location_haichau
* appraisal.thank_you
    - utter_appraisal.thank_you

## story 109
* agent.request_suggest_near_location
    - utter_ask_location
* inform{"location": "Hải Châu"}
    - utter_ask_price
* inform{"price": "trả tiền"}
    - utter_ask_moreupdates
* inform{"price": "miễn phí"}
    - utter_ask_moreupdates
* confirmation.no
    - utter_suggest_location_haichau
* appraisal.thank_you
    - utter_appraisal.thank_you


## story 110
* agent.request_suggest_near_location
    - utter_ask_location
* inform{"location": "Hải Châu"}
    - utter_ask_price
* inform{"price": "trả tiền"}
    - utter_ask_moreupdates
* confirmation.yes
    - utter_ask_moreupdates
* inform{"location": "Ngũ Hành Sơn"}
    utter_ask_moreupdates
* confirmation.no
    - utter_suggest_location_haichau_tratien
* appraisal.thank_you
    - utter_appraisal.thank_you
